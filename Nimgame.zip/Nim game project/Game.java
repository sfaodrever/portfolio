import java.util.Scanner;
public class Game
{
    private Player player1;
    private Player player2;
    int a=0;
    int score=0;
    int i=6;
    int take1 =0 ;
    String y ="Y";
    String n ="N";
    public Game()
    {
        player1 = new Player();
        player2 = new Player();
        System.out.println("Rule : Players take turns removing pieces from the pile. Players must take at least one piece but no more than half the size of the pile. The last player to take a piece loses.");
        System.out.println("And, score is show how many players turns have come and gone.");

    }
    
    public void play()
    {
        //System.out.println("1");
        if(Board.pieces >=30)
        {
            Board.order = 1;
            //System.out.println("1");
        }
        else 
        {
            Board.order=2;
            //System.out.println("1");
        }
        while(i!=5)
        {
            if(Board.order==1)
            {
                System.out.print(player1.getName());
                System.out.print(", take a pieces : ");
                Scanner sc = new Scanner(System.in);
                String take = sc.nextLine();
                take1 = Integer.parseInt(take);
                if(take1 > (Board.pieces/2))
                {
                    System.out.println("Players must take at least one piece but no more than half the size of the pile.");
                }
                else if(take1 > Board.pieces)
                {
                    System.out.println("Check the abilable number");
                }
                else if(take1 <1)
                {
                    System.out.println("Players must take at least one piece");
                }
                else
                {
                    Board.pieces=Board.pieces-take1;
                    Board.order=2;
                    score++;
                    if(Board.pieces==1)
                    {
                        Board.populate1();
                        System.out.print(player1.getName());
                        System.out.println(" Win!");
                        System.out.print("Score : ");
                        System.out.println(score);
                        i--;
                        System.out.println("Again?(Y or N) : ");
                        Scanner again = new Scanner(System.in);
                        String again1 = again.nextLine();
                        if(again1.equals(y))
                        {
                            score=0;
                            i=6;
                            take1 =0 ;
                            Board.randomInt = (int)(Math.random() * (50-10+1) + 10);
                            Board.pieces = Board.randomInt;
                            if(Board.pieces >=30)
                            {
                            Board.order = 1;
                            //System.out.println("1");
                            }
                            else 
                            {
                            Board.order=2;
                            //System.out.println("1");
                            }
                            
                            
                        }
                        else if(again1.equals(n))
                        {
                            break;
                        }
                        else
                        {
                            System.out.println("Wrong type");
                            continue;
                        }
                    }
                }
            }
            else if(Board.order==2)
            {
                System.out.print(player2.getName());
                System.out.print(", take a pieces : ");
                Scanner sc = new Scanner(System.in);
                String take = sc.nextLine();
                take1 = Integer.parseInt(take);
                if(take1 > (Board.pieces/2))
                {
                    System.out.println("Players must take at least one piece but no more than half the size of the pile.");
                }
                else if(take1 > Board.pieces)
                {
                    System.out.println("Check the abilable number");
                }
                else if(take1 <1)
                {
                    System.out.println("Players must take at least one piece");
                }
                else
                {
                    Board.pieces=Board.pieces-take1;
                    Board.order=1;
                    score++;
                    if(Board.pieces==1)
                    {
                        Board.populate1();
                        System.out.print(player2.getName());
                        System.out.println(" Win!");
                        System.out.print("Score : ");
                        System.out.println(score);
                        i--;
                        System.out.println("Again?(Y or N) : ");
                        Scanner again = new Scanner(System.in);
                        String again1 = again.nextLine();
                        if(again1.equals(y))
                        {
                            score=0;
                            i=6;
                            take1 =0 ;
                            Board.randomInt = (int)(Math.random() * (50-10+1) + 10);
                            Board.pieces = Board.randomInt;
                            if(Board.pieces >=30)
                            {
                            Board.order = 1;
                            //System.out.println("1");
                            }
                            else 
                            {
                            Board.order=2;
                            //System.out.println("1");
                            }
                            

                        }
                        else if(again1.equals(n))
                        {
                            break;
                        }
                        else
                        {
                            System.out.println("Wrong type");
                            continue;
                        }
                    }
                    
                }
            }
            Board.populate1();
        }
        
    }
}