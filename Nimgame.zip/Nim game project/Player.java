import java.util.Scanner;

public class Player
{
        private String name;
        public Player()
        {
            System.out.print("Name : ");
            Scanner sc = new Scanner(System.in);
            String newName = sc.nextLine();
            name = newName;
            System.out.println("Welcome the new game, " + name);
        }
        public String getName()
        {
          return name;
        }
        
        public void setName(String x)
        {
          name = x;
        }
 }