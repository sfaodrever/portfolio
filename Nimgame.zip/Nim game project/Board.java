
public class Board
{
    static int randomInt;
    static int pieces;
    static int order=0;
    public static void populate()
    {
        randomInt = (int)(Math.random() * (50-10+1) + 10);
        pieces = randomInt;

        System.out.println(pieces);
        for (int i = 0; i < pieces; i++)
        {
            System.out.print("|");
            if(i==9 )
            {
                System.out.println();
            }
            if(i==19 )
            {
                System.out.println();
            }
            if(i==29 )
            {
                System.out.println();
            }
            if(i==39 )
            {
                System.out.println();
            }
            
        } 
        System.out.println();
    }
    public static void populate1() {
        System.out.println(pieces);
        for (int i = 0; i < pieces; i++)
        {
            System.out.print("|");
            if(i==9 )
            {
                System.out.println();
            }
            if(i==19 )
            {
                System.out.println();
            }
            if(i==29 )
            {
                System.out.println();
            }
            if(i==39 )
            {
                System.out.println();
            }
            
        } 
        System.out.println();

        
    }
    
}