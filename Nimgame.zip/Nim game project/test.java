public class test
{
    public static void main(String[] args)
    {   
        int randomInt = (int)(Math.random() * (50-10+1) + 10);
        //System.out.println(randomInt);
        for (int i = 0; i < randomInt; i++)
        {
            System.out.print("|");
            if(i==9 )
            {
                System.out.println();
            }
            if(i==19 )
            {
                System.out.println();
            }
            if(i==29 )
            {
                System.out.println();
            }
            if(i==39 )
            {
                System.out.println();
            }
            
        } 
    }
}