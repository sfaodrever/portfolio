#include <stdio.h>
int d(int i, int a)
{
    while(1)
    {
        printf("---_----_____----------__-___--_");
    }

}
int main()
{
    int a ,b;
    d(a,b);
}
