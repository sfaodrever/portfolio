#include <stdio.h>
void calc(int num1,int num2,int op)
{
   if(op == '+')
    printf("%d %c %d = %d\n", num1, op, num2, num1 + num2);
   else if(op == '-')
    printf("%d %c %d = %d\n", num1, op, num2, num1 - num2);
    else if(op == '*')
    printf("%d %c %d = %d\n", num1, op, num2, num1 * num2);
    else if(op == '/')
    printf("%d %c %d = %d\n", num1, op, num2, num1 / num2);
    else if(op == '%')
    printf("%d %c %d = %d\n", num1, op, num2, num1 % num2);
}
int main()
{
    int num1, num2;
    char op;

    printf("�� �Է�: ");
    scanf("%d%c%d", &num1, &op, &num2);
    calc(num1,num2,op);
}
