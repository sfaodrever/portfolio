#include <stdio.h>
void add10(int a)
{


    printf("%d + 10 = %d", a, a+10);


}
int main()
{
    int a=0;
     printf("�����Է� :");
    scanf("%d", &a);
    add10(a);
}
