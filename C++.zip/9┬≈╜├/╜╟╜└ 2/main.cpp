#include <stdio.h>

int main()
{
    char qjxms;
    int a, b;

    printf("�Է� ��) 7+3 5-2 7*9 12/3 14 %2 ...\n");
    printf("���� �Է� : ");

    scanf("%d%c%d", &a, &qjxms, &b);

    switch(qjxms)
    {
    case '+':
        printf("%d + %d = %d\n", a, b, a+b);
        break;
    case '-':
        printf("%d - %d = %d\n", a, b, a-b);
        break;
    case '*':
        printf("%d * %d = %d\n", a, b, a*b);
        break;
    case '/':
        printf("%d / %d = %d\n", a, b, a/b);
        break;
    case '%':
        printf("%d %% %d = %d\n", a, b, a%b);
        break;
    }
}
