#include <stdio.h>

int main(void)
{
    int cm;
    int meter = 1;

   while(meter <= 10)
   {
           cm = meter * 100;
    printf("%d meter = %d cm\n", meter, cm);
    meter++;
   }



}
