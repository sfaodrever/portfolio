#include <stdio.h>

int main(void)
{

    int a = 1;

   while(a <= 10)
   {
       if(a % 2 == 1 )
            printf("¦�� %d\n", a);
       a++;

   }





}
