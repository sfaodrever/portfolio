#include <stdio.h>

int main(void)
{
    int a = 1;
    int b;

    printf("���? : ");

    scanf("%d", &b);

    while(a <= 11 )
    {
        printf("%d x %d = %d\n", b, a, b*a);
        a++;
    }





}
