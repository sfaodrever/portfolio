#include <stdio.h>

int main()
{
  int *pNum;
  int num = 10;

  char *pTxt;
  char txt = 'a';

  double *pDbl;
  double dbl = 3.151592;

  pNum = &num;
  pTxt = &txt;
  pDbl = &dbl;

  printf("pNum : %d num : %d  *pNum : %d &num : %d\n", pNum, num, *pNum, &num);
  printf("pTxt : %d txt : %d  *ptxt : %d &txt : %d\n", pTxt, txt, *pTxt, &txt);
  printf("pDbl : %d dbl : %f  *pDbl : %f &dbl : %d\n", pDbl, dbl, *pDbl, &dbl);
}
