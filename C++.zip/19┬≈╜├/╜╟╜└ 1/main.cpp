#include <stdio.h>

int main()
{
  int *pNum;
  int num = 10;
  pNum = &num;

  printf("%d\n", pNum);
  printf("%d\n", &num);
  printf("%d\n", *pNum);
  printf("%d\n", num);
}
