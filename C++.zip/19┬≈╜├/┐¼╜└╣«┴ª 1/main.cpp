#include <stdio.h>

int main()
{
  int *pNum;
  int num = 0;
  pNum = &num;

  scanf("%d", &num);
  printf("%d / %d", *pNum/10, *pNum%10);
}
