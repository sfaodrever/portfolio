#include <stdio.h>

using namespace std;

int main()
{
    int a, b;
    int *pa = &a;
    int *pb = &b;
    scanf("%d %d", &pa, &pb);
    printf("%d\n", *pa + *pb);
    printf("%d\n", *pa - *pb);
    printf("%d\n", *pa * *pb);
    printf("%d\n", *pa % *pb);
}
