#include <stdio.h>

int main(void)
{
    int num = 10;
    int *pNum = &num;

    printf("%d %d %d\n", num, &num, *pNum);
    printf("%d %d %d\n", *&num, *&pNum, pNum);
}
