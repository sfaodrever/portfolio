#include <stdio.h>


int main(void)
{
   int num = 15;
   double dbl = 9.36;
   char chr = 'a';

   int *pNum = &num;
   double *pDbl = &dbl;
   char *pChr = &chr;

   printf("%d %d %d\n", &num, *&pDbl, pChr);

   printf("%d %f %c\n", *pNum, *pDbl, *pChr);
}
