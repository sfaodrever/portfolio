#include <stdlib.h>
#include <stdio.h>

int main()
{
   char a = 79;
   char b = 80;
   char c = 30;
   char d = 'a';

   printf("79 = %c\n", a);
   printf("80 = %c\n", b);
   printf("30 = %c\n", c);
   printf("a  = %d\n", d);

}
