#include <stdio.h>

using namespace std;

int main()
{
    int a, b;
    printf("�� ������ �Է��ϼ��� : ");
    scanf("%d %d", &a, &b);

    printf("%d + %d = %d\n", a, b, a + b);
    printf("%d - %d = %d\n", a, b, a - b);
    printf("%d * %d = %d\n", a, b, a * b);
    printf("%d / %d = %f\n", a, b, a / b);
}
