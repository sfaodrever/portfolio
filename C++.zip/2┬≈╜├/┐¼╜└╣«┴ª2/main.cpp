#include <stdio.h>

using namespace std;

int main()
{
   int a;
   char c;
   double d;

   printf("");
   scanf("%d", &a);

   printf("");
   scanf("%lf", &d);

   printf("");
   scanf(" %c", &c);

   printf("���� : %d\n", a);
   printf("Ű : %c\n", c);
   printf("������ : %f\n", d);
}
