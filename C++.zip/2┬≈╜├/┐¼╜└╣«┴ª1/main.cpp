#include <stdlib.h>
#include <stdio.h>

int main()
{
    int a = 25;
    double b = 220.3;
    char c ='Z';

    printf("����  : %d\n", a);
    printf("Ű    : %f\n", b);
    printf("������: %c\n", c);

}
