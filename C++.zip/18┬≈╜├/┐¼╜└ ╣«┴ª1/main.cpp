#include <stdio.h>
#include <windows.h>


int main()
{
    int i, d;
    int a[20] = {0};
    int cnt = 0;
   for( i = 0 ; i < 20 ; i++)
   {
       scanf("%d", &a[i]);
       if(a[i] == 0)   break;
       cnt++;
   }
   system("cls");

   for( i = cnt-1; i >= 0 ; i--)
   {

       printf("%d ", a[i]);
   }

}
