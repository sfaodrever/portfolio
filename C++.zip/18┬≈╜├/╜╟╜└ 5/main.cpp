#include <stdio.h>



int main(void)
{
   int array[2][2] = { {1, 2}, {3, 4} };
   printf("array[0][0] = %d\n", array[0][0]);
   printf("array[0][1] = %d\n", array[0][1]);
   printf("array[1][0] = %d\n", array[1][0]);
   printf("array[1][1] = %d\n\n", array[1][1]);

   int array2[3][3] = { {1,2,3}, {4,5,6}, {7,8,9} };
   printf("array2[0][0] = %d\n", array2[0][0]);
   printf("array2[0][1] = %d\n", array2[0][1]);
   printf("array2[0][2] = %d\n", array2[0][2]);
   printf("array2[1][0] = %d\n", array2[1][0]);
   printf("array2[1][1] = %d\n", array2[1][1]);
   printf("array2[1][2] = %d\n", array2[1][2]);
   printf("array2[2][0] = %d\n", array2[2][0]);
   printf("array2[2][1] = %d\n", array2[2][1]);
   printf("array2[2][2] = %d\n", array2[2][2]);
}
