#include <stdio.h>



int main()
{
    int arr[5][4];
    int sum[5] = {0};
    int avg[5] = {0};

    for(int i = 0; i<5; i++)
    {
        for(int j = 0; j<4; j++)
        {
            scanf("%d",&arr[i][j]);

            sum[i] = arr[i][j];
        }
    }

    for(int i = 0; i<5; i++)
    {
        avg[i] = sum[i] / 4;
        if(avg[i] >= 80)
        {
            �հ�
        }
        else
        {
            ���հ�
        }
    }
}
