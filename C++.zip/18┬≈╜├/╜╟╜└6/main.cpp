#include <stdio.h>



int main(void)
{
   int array[5][5];
   int i, j;

   for(i = 0 ; i < 5 ; i++)
   {
       for(j = 0 ; j < 5 ; j++)
       {
           printf("array[%d][%d]�� ���� �Է� : ", i, j);
           scanf("%d", &array[i][j]);
       }
   }

   for(i = 0 ; i < 5 ; i++)
   {
       for(j = 0 ; j < 5 ; j++)
       {
           printf("array[%d][%d] = %d\n", i, j, array[i][j]);
       }
   }
}
