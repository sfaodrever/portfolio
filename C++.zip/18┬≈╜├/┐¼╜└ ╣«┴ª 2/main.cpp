#include <stdio.h>
#include <windows.h>
int p(int a,int b)
{

     if(a = 1)
        {
            b++;
        }
}



int main()
{
    int i, a=0,b=0,c=0,d=0,e=0,f=0,g=0;

    for(i = 1 ; i < 11 ; i++)
    {
        scanf("%d", &a);
        if(a == 2)
        {
            c++;
        }
         if(a == 3)
        {
            d++;
        }
         if(a == 4)
        {
            e++;
        }
        if(a == 5)
        {
            f++;
        }
         if(a == 6)
        {
            g++;
        }



    }
    printf("%d\n",p(a,b) ) ;
    printf("%d\n",c);
     printf("%d\n",d);
      printf("%d\n",e);
       printf("%d\n",f);
        printf("%d\n",g);


}
