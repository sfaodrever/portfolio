#include <stdio.h>

int main()
{
   int a[6][2];
   int i,j;

   for(i = 0 ; i < 6 ; i++)
   {
       printf("�Է� : ");
       for(j = 0 ; j < 2 ; j++)
       {

           scanf("%d", &a[i][j]);

       }
   }
    for(i = 0 ; i < 6 ; i++)
   {
       printf("\n");
       for(j = 0 ; j < 2 ; j++)
       {
           printf("%d ",a[i][j]);


       }
   }

}
