#include <stdio.h>
#include <windows.h>


int main()
{
    int ans;
    int guess;
    int try1 = 0;

    printf("[������] �����Է� : ");
    scanf("%d", &ans);
    system("cls");

    do
    {
        printf("[����ϱ�] : ");
        scanf("%d", &guess);
        try1++;

        if(guess > ans)
            printf("Down!\n");
        else if(guess < ans)
            printf("Up!\n");

    }while (guess != ans);
    printf("���� : %d\n", guess);
    printf("�õ� Ƚ�� : %d\n", try1);

}
