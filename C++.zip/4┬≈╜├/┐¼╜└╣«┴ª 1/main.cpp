#include <stdio.h>
int main(void)
{

   int a;

   printf("����ΰ���? : ");
   scanf("%d", &a);

   if(a >= 3 && a <= 5)
   {
       printf("��");
   }
   else if(a >= 6 && a <= 8 )
   {
       printf("����");
   }
   else if(a >= 9 && a <= 11 )
   {
       printf("����");
   }
    else if(a == 12 || a == 1 || a== 2 )
   {
       printf("�ܿ�");
   }
   return 0;

}
