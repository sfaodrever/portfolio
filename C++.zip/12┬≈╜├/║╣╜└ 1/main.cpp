#include <stdio.h>
double max1(int num1, int num2)
{
    printf("%lf",(double)num1 * num2 / 2);
    return (double)num1 * num2 / 2;
}
int main()
{
    int a, b;
    double c;
    printf("�غ� ���� �Է�  : ");
    scanf("%d %d", &a, &b);

    c = max1(a, b);

    printf("���� : %lf\n", c);
    return 0;
}
