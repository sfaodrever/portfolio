#include <stdio.h>
int max1(int a)
{
    int i;
    printf("%d��\n", a);
    for(i = 1 ; i < 10 ; i++)
    {
        printf("%d * %d = %d\n", a, i, a*i);
    }
}
int main()
{
    int a, b, c;

    printf("�����Է� : ");
    scanf("%d", &a);

    max1(a);

    return 0;
}
