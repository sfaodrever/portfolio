#include <stdio.h>
double max1(int num1, int num2, int a)
{
    return (double)num1 * num2 / 2;
}
int main()
{
    int a, b, d;
    double c;
    printf("�غ� ���� ���� �Է�  : ");
    scanf("%d %d %d", &a, &b, &d);

    c = max1(a, b, d);

    return 0;
}
