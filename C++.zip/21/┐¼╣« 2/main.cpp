#include <stdio.h>
swap(int *a, int *b)
{
    int z;
    z = *a;
    *a = *b;
    *b = z;
}

int main()
{
    int a,b;
    printf("a�� b�Է�");
    scanf("%d %d", &a, &b);

    swap(&a, &b);
    printf("a : %d \n b : %d", a, b);
}
