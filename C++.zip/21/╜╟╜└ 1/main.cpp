#include <stdio.h>


int main()
{
    int num = 10;
    int *pNum = &num;
    double dbl = 3.15;
    double *pDbl = &dbl;

    printf("*pNum�� ����� �ּҰ� : %x\n", pNum);
    printf("*pNum + 1 = %x\n", pNum+1);
    printf("*pNum - 1 = %x\n", pNum-1);

    printf("*pDbl�� ����� �ּҰ� : %x\n", pDbl);
    printf("*pDbl + 1 = %x\n", pDbl+1);
    printf("*pDbl - 1 = %x\n", pDbl-1);
}
