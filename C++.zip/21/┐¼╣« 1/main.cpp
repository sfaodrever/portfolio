#include <stdio.h>

using namespace std;

int main()
{
    int a[5] = {1,2,3,2,1};
    int *pa;
    int i = 0;
    pa = a;
    for(i = 0 ; i < 5 ; i++)
    {
        printf("%d",  *(pa+i) );
    }


}
