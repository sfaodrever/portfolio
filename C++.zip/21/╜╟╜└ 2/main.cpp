#include <stdio.h>
int main()
{
    int arr[10] = {0,1,2,3,4,5,6,7,8,9};
    int *pArr;
    pArr = arr;

    printf("�迭  : %d %d %d\n", arr[0], arr[1], arr[2]);
    printf("������ : %d %d %d\n", *pArr, *(pArr+1), *(pArr+2));
}
