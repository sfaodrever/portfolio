#include <stdio.h>
void massdata(int *pArr, int n)
{
    int i;
    for(i = 0 ; i < n ; i++)
        scanf("%d", pArr + i);
}

int main()
{
    int grade[10] = {80, 90, 60, 70, 40, 35, 75,96,88, 76};
    int i;

    for(i = 0 ; i < 10 ; i++)
        printf("%d ", grade[i]);
    printf("\n");

    massdata(grade, 10);

    for(i = 0 ; i < 10 ; i++)
        printf("%d ", grade[i]);

    printf("\n");

    return 0;
}
