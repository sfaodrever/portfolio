#include <stdio.h>


int main()
{
    int a=9999999;
    int b[10];
    int c;

    for(int i = 0 ; i < 10 ; i++)
    {
        scanf("%d", &b[i]);
        if(b[i]<a)
        {
            a=b[i];
        }
    }
    printf("%d", a);
}
