#include <stdio.h>


int main()
{
   int a,b=0,c=0,d=0;
   for(a=1;a<11;a++)
   {
       scanf("%d", &b);
       if(b%2==0)
       {
           c++;
       }
       else
       {
           d++;
       }
   }
   printf("even : %d\n", c);
   printf("odd  : %d", d);

}
