#include <stdio.h>


int main()
{
   int a=0,c=0,d=0,t=0;
   scanf("%d", &a);
   for(int b = 0 ; b<a;b++)
   {
      scanf("%d", &c);
      d=d+c;

   }

   printf("%0.1f\n",(double)d/a);
   if(d/a>=80)
   {
       printf("pass");
   }
   else
   {
       printf("fail");
   }

}
