#include <stdio.h>



int main()
{
    int a,b,c=1;
    scanf("%d", &a);
    for(;;)
    {
        c++;
        printf("%d ", a*c);
        if(c==10)
        {
            break;
        }
    }
}
