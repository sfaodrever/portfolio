#include <stdio.h>


int main()
{
   int a=0,c;
   scanf("%d", &a);
   for(int b = 1 ; b <= a;b++)
   {
      if(b%2==0)
      {
          printf("%d ", b);
      }
   }

}
