#include <stdio.h>


int main()
{
    int a,b=1,c=0;
    scanf("%d", &a);
    for(;;)
    {
        printf("%d ", a*b);
        if((a*b)%10==0)
        {
            break;
        }

        b++;
    }
}
