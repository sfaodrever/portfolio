#include <stdio.h>



int main()
{
   int a,b,c,d,e=0;
   scanf("%d %d", &a, &b);
   for(int i=1;i<=a;i++)
   {
       printf("%d ", i);
       e=e+1;

       for(int j=2;j<=b;j++)
       {

           printf("%d ", j*e);


       }





       printf("\n");
   }
}
