#include <stdio.h>


int main()
{
    int a,b;
    scanf("%d %d", &a, &b);

    for(int i=1;i<10;i++)
    {
        for(int j=a; j>=b;j--)
        {
            printf("%d * %d = %d\t", j, i, i*j);
        }
        printf("\n");
    }
}
