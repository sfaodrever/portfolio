#include <stdio.h>


int main()
{
   int a,b,c=0,d=0;
   scanf("%d", &a);
   for(int i=a;d<=a-1;d++)
   {

       scanf("%d", &b);
       c=b+c;

   }
   printf("%0.2f",(double)c/a);

}
