#include <stdio.h>


int main()
{
    int a,b=0,c=0;
    scanf("%d", &a);
    for(int i = 1; i<=a; i++)
    {
        c++;
        for(int j = 1;j<=c;j++)
        {
            printf("*");
        }
        printf("\n");
    }
}
