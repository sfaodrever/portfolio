#include <stdio.h>


int main()
{
   int a=0,c;
   scanf("%c", &a);
   for(int b = 1 ; b<19;b++)
   {
       printf("%c", a);
       c++;

   }
   printf("%d", c);
}
