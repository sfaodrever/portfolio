
#include <stdio.h>


int main()
{
    int a,b=0,c=0,g=1;
    scanf("%d", &a);
    for(int q = a ; q>=1; q--)
    {

        for(int t = a ; t>=g; t--)
        {
            printf("*");
        }
        g++;
        printf("\n");
    }

    for(int i = 1; i<=a; i++)
    {
        c++;
        for(int j = 1;j<=c;j++)
        {
            printf("*");
        }
        printf("\n");
    }

}
