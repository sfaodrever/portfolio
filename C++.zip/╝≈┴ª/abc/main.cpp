#include <stdio.h>


int main()
{
    double a[6] = {85.6,79.5,83.1,80.0,78.2,75.0};
    int b,c;
    scanf("%d %d", &b, &c);
    printf("%0.1f", a[b-1]+a[c-1]);

}
