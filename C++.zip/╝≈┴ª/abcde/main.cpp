#include <stdio.h>


int main()
{
    int a[11];
    int b=0,c=0,e=0;
    for(int i = 1 ; i <= 10 ; i++)
    {
        scanf("%d", &a[i]);

        if(i%2==0)
        {
            b=b+a[i];
        }
        else
        {
            c++;
            e=e+a[i];
        }

    }
    printf("%d\n", b);
    printf("%0.1f", (double)e/c);
}
