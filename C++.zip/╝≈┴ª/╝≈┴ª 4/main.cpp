#include <stdio.h>


int main()
{
    int a,b=0,c=0;
    for(int i = 1; i<21 ; i++)
    {
        scanf("%d", &a);
        b=a+b;
        if(a==0)
        {
            break;
        }
        c++;
    }
    printf("%d %d", b, b/c);
}
