#include <stdio.h>


int main()
{
   int a,b=1,c=0;
   scanf("%d", &a);

   for(;;)
   {
       b++;
       if(b%5==0)
       {
           c=c+b;
       }
       else if(a<b+1)
       {
           break;
       }
   }
   printf("%d", c);
}
