#include <stdio.h>


int main()
{
   int a=0,c=0,d=0;

   for(int b = 1 ; b<11;b++)
   {
      scanf("%d", &a);
      if(a%3==0)
      {
          c++;
      }
      else if(a%5==0)
      {
          d++;
      }

   }
   printf("3�� ��� %d\n", c);
   printf("5�� ��� %d", d);

}
