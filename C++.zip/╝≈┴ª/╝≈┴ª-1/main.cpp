#include <stdio.h>


int main()
{
    int a,b=1,c=0,d=0;

    scanf("%d", &a);

    for(;;)
    {
        b++;
        if(d<=a)
        {
            break;
        }

        else if(b%2!=0)
        {
            c++;
            d=d+b;
        }
    }
    printf("%d %d", c, d);
}
