#include <stdio.h>


int main()
{
   int a=0;

   for(int b = 10 ; b<=20;b++)
   {
      printf("%d ", b);
   }

}
