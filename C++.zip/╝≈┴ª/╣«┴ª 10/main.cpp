#include <stdio.h>



int main()
{
   int a=0,b=0;
   scanf("%d %d", &a, &b);

   for(;;)
   {
       if(a<b)
       {
           for(;;)
           {

               printf("%d ", a);

               if(a==b)
               {
                   break;
               }
               a++;
           }
       }
       else if(b<a)
       {
           for(;;)
           {

               printf("%d ", b);
               if(b==a)
               {
                   break;
               }
               b++;
           }
       }
       break;
   }
}
