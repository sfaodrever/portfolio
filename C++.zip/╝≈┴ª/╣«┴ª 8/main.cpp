#include <stdio.h>



int main()
{
   int a,b=2,i,j=1;

  for(a=2;a<5;a++)
  {
      for(b=1;b<6;b++)
      {
          printf("%d * %d = %d\t", a, b, a*b);
      }
      printf("\n");
  }
}
