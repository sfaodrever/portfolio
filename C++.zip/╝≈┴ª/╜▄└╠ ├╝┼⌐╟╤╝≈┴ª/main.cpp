
#include <stdio.h>

int main()
{
    int a,b=9999999999999,c=0,d=-9999999999999;
    for(int i=1;i<=100;i++)
    {
        scanf("%d", &a);
        if(a==999)
        {
            break;
        }
        if(a>d)
        {
            d=a+c;
        }
        else if(a<b)
        {
            b=a+c;
        }

    }
    printf("Max : %d\n", d);
    printf("Min : %d", b);
}

