#include <stdio.h>


int main()
{
    char a[10] = {'A','B','C','D','E','F','G','H','I','J'};
    printf("%c %c %c", a[0], a[3], a[6]);

}
