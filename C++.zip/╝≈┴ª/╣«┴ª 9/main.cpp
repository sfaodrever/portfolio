#include <stdio.h>



int main()
{
   int a,b=0;

   scanf("%d", &a);
   for(;;)
   {
       printf("jungol\n");
       b++;
       if(b==a)
       {
           break;
       }
   }
}
