#include <stdio.h>



int main()
{
   int a,b,i=7,j=3;

   for(a=2;a<7;a++)
   {
       printf("%d ", a);
       for(b=j;b<i;b++)
       {
           printf("%d ", b);
       }
       printf("\n");
       i++;
       j++;
   }
}
