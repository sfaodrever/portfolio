#include <stdio.h>


int main()
{
    int num,num2;
    int sum = 0;
    int i,j=0;
    double avg = 0;

    scanf("%d %d",&num,&num2);

    for(i = num; i <= num2 ; i++)
    {
        if(i % 3 == 0 || i % 5 == 0)
        {
            sum = sum + i;
            j++;
        }

    }
    avg = (double)sum / j;
    printf("%d\n",sum);
    printf("%lf",avg);
}
