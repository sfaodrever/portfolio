#include <stdio.h>


int main()
{
   int a=0,c=0,d=0;
   scanf("%d", &a);
   for(int b = a ; b<=100;b++)
   {
      c=c+b;
   }
    printf("%d", c);
}
