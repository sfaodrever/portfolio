#include <stdio.h>

using namespace std;

int main()
{
   int a , q , w, d=999999;

   printf("3���� ������ �Է��ϼ���. : \n");

   scanf("%d %d %d", &a, &q, &w);

   if(d > a)
   {
       d = a;
   }
    if(d > q)
   {
       d = q;
   }

   if(d > w)
   {
      d = w;
   }

    printf("%d", d);

   return 0;
}
