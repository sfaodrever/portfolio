#include <stdio.h>


int main(void)
{
    int i;
    int j;

    printf("����Դϱ�?");
    scanf("%d", &i);




    for(j = 1 ; j <= 9 ; j++)
    {

        printf("%d * %d = %d \n",i, j ,i*j);
    }



}
