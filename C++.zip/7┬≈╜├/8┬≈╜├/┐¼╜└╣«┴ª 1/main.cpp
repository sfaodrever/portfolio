#include <stdio.h>


int main(void)
{

    int i = 1;





   for(i = 1 ; i <= 10 ; i++)
   {

       printf("%d meter = %d cm\n",i , i * 100 );
   }



}
