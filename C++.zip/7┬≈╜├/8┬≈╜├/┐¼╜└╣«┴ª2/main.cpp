#include <stdio.h>


int main(void)
{

    int i = 1;





   for(i = 1 ; i <= 10 ; i++  )
   {
        if(i % 2 == 0)
        {

            printf("¦�� %d\n", i);
        }
   }




}
