#include <stdio.h>


int main(void)
{
    int i = 0;
    int j = 0;

    while(i < 5)
    {


         while(j < 5)
         {
             printf("\t(while2)j = %d\n", j);
             j++;
             //printf("%d: %d", i, j);
         }
         i++;
         j = 0;
    }
}
