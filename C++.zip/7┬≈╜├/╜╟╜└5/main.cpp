#include <stdio.h>

int main(void)
{


    int dan = 2;
    int i = 1;

    printf("������ ���\n ");


   while(dan <= 9)
   {

            printf("%d��\n", dan);
            while(i <= 9)
            {
                printf("%d *%d = %2d\n", dan, i, dan*i);
                i++;
            }
            i = 1;
            dan++;

            printf("\n");
   }





}
