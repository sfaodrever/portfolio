#include <stdio.h>

using namespace std;

int main()
{
   int a , q;

   printf("���� �ΰ��� �Է��ϼ��� : \n");

   //scanf("%d", &a);
   //scanf("%d", &q);

   scanf("%d %d", &a, &q);

   if(q > a )
   {
       printf("%d - %d = %d\n", q, a, q-a);
   }
   else{
        printf("%d - %d = %d\n", a, q, a-q);

   }

   return 0;
}
