#include <stdio.h>

int main(void)
{

    int a = 1;
    int dan;
    int p;

    printf("�� / ���� �Է� : ");
    scanf("%d %d" , &dan , &p);

   while(a <= p)
   {

            printf("%d * %d = %d\n", dan, a, dan*a);
            a++;
   }





}
