#include <stdio.h>
#include <windows.h>



int main()
{
    int min, sec, msec;


    printf("Ÿ�̸� �Է�(1�� �̻�, �д���) : ");
    scanf("%d", &min);

    system("cls");



 for(min = min - 1 ; min >= 0 ; min--)
 {
     for( sec = 60 ; sec >= 0 ; sec--)
     {
         if(min == 0 && sec == 0)
         {
             printf("Time Over!\a");
             break;
         }
         printf("���� �ð� : %02d�� %02d��\n", min, sec);
         Sleep(980);
         system("cls");
     }
 }






}
