#include <stdio.h>



int main(void)
{
    int i, j;
    int sq;

    printf("���簢���� ũ�⸦ �Է��ϼ��� : ");
    scanf("%d", &sq);


    for(i = 0 ; i < sq ; i ++)
    {
        for(j = 0 ; j < sq ; j++)
    {
        printf("* ");
    }
    printf("\n");
    }



}
