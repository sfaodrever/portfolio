#include <stdio.h>



int main()
{
    int i;
    int d;
    char str1[20] = "hello roperson";
    scanf("%d", &d);

    str1[d] = '\0';

    printf("%s",str1);
    return 0;
}
