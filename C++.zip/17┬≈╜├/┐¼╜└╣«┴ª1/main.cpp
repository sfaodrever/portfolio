#include <stdio.h>



int main()
{

    char d[20] = "hello";
    char n[20] ;

    printf("%s",d);

    scanf("%s", n);
    printf("%s", n);
}
