#include <stdio.h>
int main(void)
{
    char str1[10] = {'r','o','p','e','r','s','o','n'};
    char str2[10] = "roperson";

    printf("str1 : %c%c%c%c%c%c%c%c\n",
           str1[0],str1[1],str1[2],str1[3],
           str1[4],str1[5],str1[6],str1[7]
           );
    printf("str2 : %s\n", str2);

    return 0;
}
