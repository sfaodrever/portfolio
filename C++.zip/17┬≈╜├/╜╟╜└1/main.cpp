#include <stdio.h>
int main(void)
{
    int num1[5] = {1,2,3,4,5};
    int num2[5] = {1};
    int num3[5];
    double num4 [5] = {1.2, 2.5, 3.4};

    int i = 0;

    for(i = 0 ; i < 5 ; i++)
    {
        printf("[num1 : %d\t", num1[i]);
        printf("[num2 : %d\t", num2[i]);
        printf("[num3 : %d\t", num3[i]);
        printf("[num4 : %f\n", num4[i]);
    }
    return 0;
}
