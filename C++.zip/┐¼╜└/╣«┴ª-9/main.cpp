#include <stdio.h>
#include <windows.h>


int main()
{

    int a=0,b=0,c=0;
    scanf("%d %d %d", &a, &b, &c);
    system("cls");
    if(a<b)
    {
        if(a<c)
        {
            printf("%d", a);
        }
        else
        {
            printf("%d", c);
        }

    }
    else if(a>b)
    {
        if(b<c)
        {
            printf("%d", b);
        }
        else
        {
            printf("%d", c);
        }
    }
    else if(b<c)
    {
        if(b<a)
        {
            printf("%d", b);
        }
        else
        {
            printf("%d", a);
        }
    }

}
