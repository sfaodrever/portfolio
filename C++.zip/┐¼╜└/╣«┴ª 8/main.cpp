#include <stdio.h>

int main()
{
    int a=0,b=0,c=0,i=0;

    for(i=0;i<20;i++)
    {
        scanf("%d", &a);
        b++;
        if(a==0)
        {
            break;
        }
        c=c+a;
    }
    printf("%d ",c);
    printf("%d",c/b);

}
