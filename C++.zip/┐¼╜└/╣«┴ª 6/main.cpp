#include <stdio.h>

int main()
{
    int a=0,b=0,c=0,d=0;

    printf("�� �� �Է�: ");

    scanf("%d %d",&a, &b);

    for(int i = a; i <= b ; i++)
    {

        if(i % 3 == 0 || i % 5 ==0 )
        {

            c=c+i;
            d++;

        }


    }
    printf("%d\n",c);
    printf("%0.1lf",(double)c/d);

}
