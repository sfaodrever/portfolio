#include <stdio.h>

int main()
{
    int a=0,b=0,c=0;
    printf("�� �Է�: ");

    for(;;)
    {
        scanf("%d",&a);
        if(a==0)
            break;
        if(a%2==0)
        {
            b++;
        }
        else
        {
            c++;
        }
    }

            printf("odd : %d\n",b);
            printf("even: %d",c);
}
