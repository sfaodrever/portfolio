#include <stdio.h>
#include <windows.h>


int main()
{
    int a,b;
    scanf("%d", &a);
    system("cls");

    if(a>=20)
    {
        printf("����");
    }
    else if(a<20)
    {
        printf("%d years later", 20-a);
    }
}
