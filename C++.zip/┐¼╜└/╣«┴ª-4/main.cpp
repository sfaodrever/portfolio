#include <stdio.h>
#include <windows.h>


int main()
{
    int a,b;
    scanf("%d", &a);
    system("cls");

    if(a<=50.80)
    {
        printf("Flyweight");
    }
    else if(a<=61.23)
    {
        printf("Lightweifht");
    }
    else if(a<=72.57)
    {
        printf("midleweight");
    }
    else if(a<=88.45)
    {
        printf("cruiserweight");
    }
    else if(a>88.45)
    {
        printf("Heavyweight");
    }

}
