#include <stdio.h>

int main()
{
    int a=0,b=0,c=0,d=0;

    printf("�� �� �Է�: ");

    scanf("%d %d",&a, &b);

    for(int i = a; i >= b ; i--)
    {

        for(int j = 1 ; j <= 9 ; j++)
        {
            printf("%d * %d = %d\n",i, j, i*j);
        }
    }
}
