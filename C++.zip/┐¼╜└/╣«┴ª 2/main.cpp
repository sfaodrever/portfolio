#include <stdio.h>

int main()
{
    int a;
    printf("�� �Է�: ");
    scanf("%d",&a);

    if(a == 0)
    {
        printf("zero");
    }
    else if(a < 0)
    {
        printf("minus");
    }
    else if(a > 0)
    {
        printf("plus");
    }
}
