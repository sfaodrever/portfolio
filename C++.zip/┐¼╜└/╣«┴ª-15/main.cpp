#include <stdio.h>
#include <windows.h>


int main()
{
    int a,b=0,c=0;

    for(;;)
    {
        scanf("%d", &a);
       if(a>=100)
       {
           b=b+a;
           c++;
           break;
       }
       b=b+a;
       c++;

    }
    printf("%d\n", b);
    printf("%0.1lf", (double)b/c);
}

