#include <stdio.h>
#include <windows.h>


int main()
{
    int a;
    scanf("%d", &a);
    system("cls");

    if(a%400==0)
    {
        printf("����");
    }
    else if(a%4==0 && a%100!=0)
    {
        printf("����");
    }
    else
    {
        printf("���");
    }
}
