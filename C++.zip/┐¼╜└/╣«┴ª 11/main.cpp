#include <stdio.h>

int main()
{
    int num,num2;
    int i = 1;
    scanf("%d",&num);

    for(;;)
    {
        num2 = num * i;
        printf("%d ",num2);
        i++;
        if(num2 % 10 == 0)
        {
            break;
        }
    }
}
