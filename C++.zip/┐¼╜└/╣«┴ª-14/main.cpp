#include <stdio.h>
#include <windows.h>


int main()
{
    int a;

    for(;;)
    {
        scanf("%d", &a);
        if(a<0)
       {
           printf("����\n");
       }
       else if(a>0)
       {
           printf("���\n");
       }
       else
       {
           break;
       }
    }

}

