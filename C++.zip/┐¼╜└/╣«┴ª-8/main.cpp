#include <stdio.h>
#include <windows.h>


int main()
{

    int b;
    scanf("%d", &b);
    system("cls");
    if(b>=4)
    {
        printf("scholarship");
    }
    else if(b>=3)
    {
        printf("next semester");
    }
    else if(b>=2)
    {
        printf("seasonal semester");
    }
    else if(b<2)
    {
        printf("retake");
    }
}
