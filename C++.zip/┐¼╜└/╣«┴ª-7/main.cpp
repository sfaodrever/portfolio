#include <stdio.h>
#include <windows.h>


int main()
{
    char a;

    scanf("%c", &a);
    system("cls");





    if(a == 'A')
    {

            printf("����");

    }
    else if(a == 'B')
    {

            printf("��");

    }
    else if(a == 'C')
    {
        printf("������");
    }
    else if(a == 'D')
    {
        printf("����Ʈ");
    }
    else if(a == 'F')
    {
        printf("�緲");
    }
    else
    {
        printf("����");
    }
}
