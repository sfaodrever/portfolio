#include <stdio.h>

int main()
{
    int a=0,b=0,c=0;
    printf("�� �Է�: ");

    for(;;)
    {
        scanf("%d",&a);

        if(a>100)
        {
           break;
        }
        b++;

       c=c+a;
    }
    printf("��:%d\n",c);
    printf("���:%0.1lf",(double) c/b");

}
