#include <stdio.h>

int main()
{
   int a=0,b=0,i=0;
   scanf("%d %d",&a, &b);
   for(i=1;i<=a;i++)
   {
       printf("\n");
       for(int j=1;j<=b;j++)
       {
           printf("%d ",i*j);
       }
   }

}
