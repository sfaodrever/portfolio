#include <stdio.h>
#include <windows.h>


int main()
{
    int a,b;
    scanf("%d", &a);
    system("cls");
    printf("%d\n", a);
    if(a<0)
    {
        printf("minus");
    }
}
