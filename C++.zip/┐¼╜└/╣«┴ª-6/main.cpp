#include <stdio.h>
#include <windows.h>


int main()
{
    char a;
    int b;
    scanf("%c %d", &a, &b);
    system("cls");





    if(a == 'M')
    {
        if(b>=18)
        {
            printf("man");
        }
        else
        {
            printf("boy");
        }
    }
    else
    {
        if(b>=18)
        {
            printf("woman");
        }
        else if(b<18)
        {
            printf("girl");
        }
    }
}
