#include <stdio.h>


int main()
{
    int a[5][4] = {0};
    int sum[5]={0};
    int avg[5] = {0};
    int cnt = 0;

    for(int i=0;i<5;i++)
    {
        for(int j=0;j<4;j++)
        {
            scanf("%d",&a[i][j]);
            sum[i] = sum[i] + a[i][j];
        }
    }

    for(int i = 0; i<5; i++)
    {
        avg[i] = sum[i]/4;

        if(avg[i] >= 80.0)
        {
            printf("pass\n");
            cnt++;
        }
        else
            printf("fail\n");
    }
    printf("Successful = %d",cnt);
}
