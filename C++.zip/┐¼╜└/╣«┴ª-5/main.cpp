#include <stdio.h>
#include <windows.h>


int main()
{
    int a=0,b=0;
    scanf("%d %d", &a, &b);
    system("cls");
    printf("%d %d\n", a, b);
    if(a>=4 && b>=4)
    {
        printf("A");
    }
    if(a>=3 && b>=3)
    {
        printf("B");
    }
    else
    {
        printf("C");
    }
}
