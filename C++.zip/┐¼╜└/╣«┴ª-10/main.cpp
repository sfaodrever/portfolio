#include <stdio.h>
#include <windows.h>


int main()
{

    int a,b;
    scanf("%d %d", &a, &b);
    system("cls");
    if(a<b)
    {
        printf("%d", b-a);
    }
    else
    {
        printf("%d", a-b);
    }
}
