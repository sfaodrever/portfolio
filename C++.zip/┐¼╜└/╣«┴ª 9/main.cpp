#include <stdio.h>

int main()
{
    int a=0,b=0,c=0,d=0;

    scanf("%d",&a);
    for(int i=1;i<=a;i++)
    {
        printf("\n");h
        for(int j=1;j<=a;j++)
        {
            printf("(%d, %d)",i, j);
        }
    }

}
