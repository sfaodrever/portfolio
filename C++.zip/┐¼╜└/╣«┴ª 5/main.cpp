#include <stdio.h>

int main()
{
    int a,b=0,c=0;

    for(;;)
    {
        scanf("%d",&a);

        if(a==0)
        {
            break;
        }
        if(a%3 == 0 || a % 5 == 0)
        {
            continue;
        }
        else
        {
            c++;
        }
    }
    printf("%d",c);
}
