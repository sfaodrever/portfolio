#include <stdio.h>
#include <windows.h>


int main()
{
    int a=0,b=0;
    scanf("%d %d", &a, &b);
    system("cls");
    printf("%d\n", b+100-a);
    if(b+100-a>0)
    {
        printf("��");
    }
}
