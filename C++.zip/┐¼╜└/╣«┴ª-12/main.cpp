#include <stdio.h>
#include <windows.h>


int main()
{
    int a=1;
    while(a < 16)
    {
        printf("%d", a);
        a++;
    }
}
