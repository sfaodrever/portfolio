#include <stdio.h>
#include <windows.h>


int main()
{
    int a;
    for(;;)
    {
        scanf("%d", &a);
        if(a%3==0)
        {
            printf("%d\n", a/3);
        }
        else if(a==-1)
        {
            break;
        }
    }



}

