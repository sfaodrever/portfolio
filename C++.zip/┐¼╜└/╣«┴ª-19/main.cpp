#include <stdio.h>
#include <windows.h>


int main()
{
    int a,b,odd=0,even=0;
    for(;;)
    {
        scanf("%d", &a);

        if(a==0)
        {
            break;
        }

        if(a%2==0)
        {
            odd++;
        }

        else
        {
            even++;
        }


    }
    printf("odd  : %d", odd);
    printf("even : %d", even);

}

