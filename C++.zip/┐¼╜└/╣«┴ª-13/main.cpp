#include <stdio.h>
#include <windows.h>


int main()
{
    int a=1,b,c=0;
    scanf("%d", &b);

   while(a <= b)
   {
       c=a+c;
       a++;
   }
   printf("%d",c);
}
