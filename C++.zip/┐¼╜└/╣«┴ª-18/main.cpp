#include <stdio.h>
#include <windows.h>


int main()
{
    int a,b;
    scanf("%d", &a);
    for(b=1;b<=a;b++)
    {
        printf("%d", b);
    }

}

