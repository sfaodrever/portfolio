#include <stdio.h>

int z(int a)
{
    int q= 0;
    int b;

    scanf("%d", &a);

    for(b = 1 ; b <= a ; b++)
    {
        if(a % b == 0)
        {
            printf("%d\n", b);
            q++;
        }
    }

    return q;
}

int main()
{
    int b;

    printf("���� �Է� : ");



    printf("�������:%d", z(b));

    return 0;
}
