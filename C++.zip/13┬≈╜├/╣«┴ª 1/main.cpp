#include <stdio.h>
void d(int num)
{
    int a=1, b=0, c=0;

    if(b == 6)
    {
        a++;
    }
    else
    {
        for(b = 1 ; b <= 6 ; b++)
        {
            printf("%d ", a);
            for(c = 1 ; c <= num ; c++)
            {
                 printf("%d", b);
            }
            printf("\n");

        }
    }


}


int main()
{
    int num;

    printf("�ֻ����� ��� �����ǰǰ���?");
    scanf("%d", &num);

    d(num);
    return 0;
}
