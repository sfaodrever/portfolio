#include <stdio.h>

void d()
{
    printf(")<");
    d();
}

int main()
{
    d();
    return 0;
}
