#include <stdio.h>
int z()
{
     int a;
     int sum = 0 ;
    for(int i = 0 ; i < 5 ; i++)
    {
        scanf("%d", &a);
        if(a < 0)
        {

            a =a * -1;
        }
        sum = a+ sum;
    }
    return sum;
}
int main()
{

    printf("%d", z());
}
