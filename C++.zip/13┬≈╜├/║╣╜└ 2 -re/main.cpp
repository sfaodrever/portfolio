#include <stdio.h>
int d(int i, int a)
{
    int b=0;

    for(i = 1 ; i < 6 ; i++)
    {
        scanf("%d", &a);
        if(a < 0)
        {
            a = a * -1;
        }
        b = b + a;
    }
    return b;

}
int main()
{
    int i, a;
    printf("%d", d(a,i));
}
