#include <stdio.h>
#include <windows.h>
void d(int num)
{



    if(num == 1)
    {
        printf("%d\n", num);
        return;
    }

    printf("%d\n", num);
    num--;

    d(num);
}


int main()
{
    int num;
     scanf("%d", &num);
     system("cls");
    d(num);
    return 0;
}
