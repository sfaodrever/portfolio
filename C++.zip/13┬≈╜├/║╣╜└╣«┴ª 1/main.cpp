#include <stdio.h>
int z(int a)
{
    int b;
    int d=0;

    for(b = 1 ; b <= a ; b++)
    {
        if(a % b == 0)
        {
            printf("%d\n", b);
            d++;

        }

    }
           printf("��� ����: %d", d);

    return 0;
}
int main()
{
    int a,b;
    printf("�����Է� : ");
    scanf("%d", &a);

    z(a);


}
