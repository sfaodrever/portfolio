#include <stdio.h>
int d(int a)
{
    if(a == 1)
    {
        return 1;
    }
    else
    {

        return a * d(a-1);
    }

}


int main()
{
    int a;
    printf("���ڸ� �Է��ϼ��� : ");
    scanf("%d", &a);

    printf("%d\n", d(a));
    return 0;
}
