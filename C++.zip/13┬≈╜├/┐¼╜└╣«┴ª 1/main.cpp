#include <stdio.h>
int a, b;

void z()
{
    printf("%d + %d = %d\n", a, b, a+b);
}
void q()
{
    printf("%d - %d = %d\n", a,b, a-b);
}
void r()
{
    printf("%d X %d = %d\n", a, b, a*b);
}
void e()
{
    printf("%d / %d = %d\n", a, b, a/b);
}
int main()
{

    scanf("%d %d", &a, &b);
    z();
    q();
    r();
    e();
}
