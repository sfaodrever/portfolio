#include <stdio.h>

int main(void)
{
    int a;  //�Է�
    int b=0; // ���

    int i = 1;

    scanf("%d", &a);
    while(i <= a){

        b = b + i;

        i++;
    }

    printf("%d\n", b);





}
