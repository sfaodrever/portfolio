#include <stdio.h>
#include <windows.h>
void z()
{
    printf("Hello world!\n");
    printf("안녕하세요??\n");

}

int main()
{
    int num;

    z();

    printf("숫자 입력 : ");
    scanf("%d", &num);

    if(num == 0)
    {
        printf("함수 호출\n");
        z();
    }
    else
        printf("호출 안함\n");

    printf("프로그램 종료\n");
}
