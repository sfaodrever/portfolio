#include <stdio.h>


int z()
{
    printf("1\n");
}


int main()
{
    int a;
    int i;

    scanf("%d",&a);

    for(i = 0 ; i < a ; i++)
    {
       z();
    }
}
