#include <stdio.h>
#include <windows.h>
int Power(int num)
{
    return num * num;
}

int main()
{
    int a;
    int result;



    printf("���� �Է� : ");
    scanf("%d", &a);

   Power(a);

   result = Power(a);

   printf("��� 1: %d\n", result);
   printf("��� 2 : %d\n", Power(a));

   return 0;
}
