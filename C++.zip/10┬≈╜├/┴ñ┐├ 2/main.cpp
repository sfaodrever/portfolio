#include <stdio.h>

int z(int a, int b)
{
    int i;
    int j = 1;
    for(i = 0 ; i < b ; i++)
    {
        j = j * a ;
    }
        printf("%d", j);
}

int main()
{
    int a, b;


    scanf("%d %d",&a,&b);
    z(a,b);
}
