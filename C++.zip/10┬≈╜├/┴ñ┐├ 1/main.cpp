#include <stdio.h>

int z(int a)
{
    printf("%f",a*a*3.14);
}

int main()
{
    int a;

    scanf("%d",&a);
    z(a);
}
