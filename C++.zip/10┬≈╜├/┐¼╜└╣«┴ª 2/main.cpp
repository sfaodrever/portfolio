#include <stdio.h>
#include <windows.h>
int sum(int sum1, int sum2)
{
    return sum1 * sum2;
}

int main()
{
    int a, b;




    printf("���� �Է� : ");
    scanf("%d %d", &a, &b);

  printf("�հ� : %d\n", sum(a, b));
}
