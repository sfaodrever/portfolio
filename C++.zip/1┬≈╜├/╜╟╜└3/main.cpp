#include <stdio.h>

using namespace std;

int main(void)
{


    printf("Hello Roperson!");
    printf("3+4=?");
    printf("�ȳ��ϼ���?");
    printf("  ****    *******      **********         ?");

    return 0;

}
