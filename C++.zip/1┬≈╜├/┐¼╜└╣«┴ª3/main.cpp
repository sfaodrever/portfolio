#include <stdio.h>
int main(void)
{


    printf("%s\n", "�ڶ��");
    printf("%d��\n", 15);
    printf("%0.1fcm\n", 179.8);
    printf("%d + %d = %d\n", 85,15, 85+15);
    printf("%d + %d = %d\n", 27,45, 27-45);
    return 0;

}
