#include <stdio.h>

using namespace std;

int main(void)
{


    printf("        Hello       Roperson!");

    return 0;

}
