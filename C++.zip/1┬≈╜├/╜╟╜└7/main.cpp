#include <stdio.h>
int main(void)
{


    printf("1) %d + %d = %d\n", 5, 10, 5+10);
    printf("3) %d * %d = %d\n", 42, 27, 42-27);
    printf("3) %d - %d = %d\n", 256, 256, 256*256 );
    printf("4) %d / %d = %d\n", 26, 4, 26/4);

    return 0;

}
