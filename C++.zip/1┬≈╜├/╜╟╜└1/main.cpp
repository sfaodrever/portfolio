#include <stdio.h>

int main(void)
{
   int name;

   printf("�̸��� �Է��ϼ���\n");
   scanf("%d", &name);

    printf("+-+-+-+-+-+-+-+-+\n");
   printf("    |%d|\n" , name);
   printf("+-+-+-+-+-+-+-+-+\n");





}
