#include <stdio.h>

using namespace std;

int main(void)
{


    printf("Hello Roperson!\n");
    printf("3+4=?\n");
    printf("�ȳ��ϼ���?\n");
    printf("  ****\n    *******\n      **********\n         ?\n");

    return 0;

}
