#include <stdio.h>

using namespace std;

int main(void)
{


    printf("1) %d\n", 28+48);
    printf("2) %d\n" , 36-63);
    printf("3) %d\n", 12/2);
    printf("%d", 12 % 5);


    return 0;

}
