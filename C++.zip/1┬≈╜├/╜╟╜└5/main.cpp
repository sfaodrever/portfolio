#include <stdio.h>

using namespace std;

int main(void)
{


    printf("1) 111*9\n");
    printf("2) %d\n" , 111*90);

    printf("3) 1234567890-112450\n");
    printf("4) %d\n" ,1234567890-112450 );


    return 0;

}
