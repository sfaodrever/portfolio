#include <stdio.h>

using namespace std;

int main(void)
{


    printf("*************\n");
    printf("*           *\n");
    printf("* P A N D A *\n");
    printf("*           *\n");
    printf("*************");

    return 0;

}
