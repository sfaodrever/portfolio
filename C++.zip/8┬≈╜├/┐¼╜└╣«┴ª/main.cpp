#include <stdio.h>
int main()
{
   int i, j;
   int height;

   printf("�ﰢ�� ���̸� �Է��ϼ��� :");
   scanf("%d", &height);

  for(j = 1 ; j <= height ; j++)
{
    for(i = 1 ; i <= height-j ; i++)
    {
        printf(" ");
    }
    for(i = 1 ; i <= j ; i++)
    {
        printf("*");
    }
    printf("\n");
}
}







