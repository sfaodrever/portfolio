#include <stdio.h>



int main()
{
    int i, j;
    int height;

    printf("���ﰢ�� ũ�� �Է� : ");
    scanf("%d", &height);

    for(i = 0 ; i < height ; i++ )
    {
        for(j= 0 ; j < height-i ; j++)
        {
            printf(" ");

        }
        for( j = 0 ; j <= 2*i ; j++)
        {
            printf("*");
        }
        printf("\n");
    }
}
