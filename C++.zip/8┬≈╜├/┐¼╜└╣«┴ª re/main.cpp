

  #include <stdio.h>
int main(void)
{
   int a = 0, b = 0, c = 0;
   int i;

   scanf("%d", &a);

   for(i = 1 ; i <= a ; i++)
   {
       scanf("%d", &b);
       c = b + c;
   }

printf("%d", c / a);
}
