#include <stdio.h>



int main()
{
    int i, j;
    int a, b;

    printf("��� �� �Է� :");
    scanf("%d %d", &a, &b);

    for(i = 1 ; i <= a ; i++ )
    {
        for(j = 1 ; j<=  b ; j++)
        {
            printf("%d",&);
        }


        printf("\n");
    }



}

