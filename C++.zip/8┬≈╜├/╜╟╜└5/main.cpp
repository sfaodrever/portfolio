#include <stdio.h>
int main()
{
   int i, j;
   int height;

   printf("�̵ �ﰢ�� ũ�� �Է�(Ȧ��) :");
   scanf("%d", &height);

  for(i = 0 ; i < height ; i++)
{
    if(i <= height / 2 )
    {
         for(j = 0 ; j < i+1 ; j++)
    {
        printf("*");
    }

}
else
{
    for( j = 0 ; j < height - i ; j++ )
    {
        printf("*");
    }

}
printf("\n");
}
}














