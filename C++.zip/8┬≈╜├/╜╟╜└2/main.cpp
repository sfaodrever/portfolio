#include <stdio.h>
int main(void)
{

    int dan;
    int i;



    for( dan = 2 ;dan < 10 ; dan++)
    {
        printf("%d�� \n", dan);
        for(i = 1 ; i <=9 ; i++)
        {
            printf("%d * %d = %d\n", dan, i, dan * i);
        }

    }






}
