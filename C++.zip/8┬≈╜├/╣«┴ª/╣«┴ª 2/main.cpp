#include <stdio.h>



int main()
{
    int a, i,j;
    int p, b=1;



    printf("�ڿ��� �Է� :");
    scanf("%d", &a);

    for(i = 0 ; i < a ; i++ )
    {
        for(j =0; j < i ; j++ )
        {
            printf(" ");
        }
        for(j = a; j > i; j--)
        {
            printf("%d", b);
            b++;
        }

        printf("\n");
    }




}
