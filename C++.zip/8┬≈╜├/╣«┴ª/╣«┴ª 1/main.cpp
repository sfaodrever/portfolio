#include <stdio.h>



int main()
{
    int a, b=0, p = 0;
    int i;

    for(i = 0 ; i < 20 ; i++)
    {
        scanf("%d", &a);
        if(a == 0) break;
        b = b+a;
        p++;

    }
    printf("����: %d  ���: %f", b, (double)b/(i-1));

}
