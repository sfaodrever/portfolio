#include <stdio.h>



int main()
{
    int a, i,j;
    int b=1;

    printf("�ڿ��� �Է� :");
    scanf("%d", &a);

    for(i = 0 ; i < a ; i++ )
    {

        for(j =0; j < a; j++)
        {
            printf("%d", b);

            b = b+ 2;
            if(b==11)
            {

                b = 1 ;

            }

        }

        printf("\n");
    }




}
