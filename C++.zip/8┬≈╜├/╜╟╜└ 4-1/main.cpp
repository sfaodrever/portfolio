#include <stdio.h>
int main()
{
   int i, j;
   int height;

   printf("�ﰢ�� ���̸� �Է��ϼ��� :");
   scanf("%d", &height);

  for(i = 0 ; i < height ; i++)
{
    for(j = 0 ; j < i+1 ; j++)
    {
        printf("*");
    }
    printf("\n");
}
}







