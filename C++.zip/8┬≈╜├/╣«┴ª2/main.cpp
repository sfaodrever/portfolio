#include <stdio.h>



int main()
{
 int even = 0, odd = 0;
 int i;
 int n;


 for( i = 1 ; i < 11 ; i++)
 {

     scanf("%d", &n );
     if(n % 2 == 0 ) even++;
     else if(n % 2 == 1 ) odd++;

 }

printf("%d ", even);
printf("%d ", odd);
}

