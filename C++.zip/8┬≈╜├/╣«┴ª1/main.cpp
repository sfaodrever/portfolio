#include <stdio.h>



int main()
{
    int i;
    int a, b;


    printf("정수 두개입력 :");
    scanf("%d %d", &a, &b);

    if( a <= b )
    {
        for(i = a ; i <= b ; i++)
        printf("%d\n", i);
    }
    else
    {
        for(i = b ; i <= a ; i++)
        printf("%d\n", i);
    }



}
