#include <stdio.h>


int main(void)
{
    int num[5] = {1,2,3,4,5};
    int num2,num3,num4,num5;

    num2 = num[0] + num[1];
    num3 = num[1] - num[2];
    num4 = num[2] * num[3];
    num5 = num[3] / num[4];

    printf(" num2 = %d\n", num2);
    printf(" num3 = %d\n", num3);
    printf(" num4 = %d\n", num4);
    printf(" num5 = %d\n", num5);

    return 0;

}
