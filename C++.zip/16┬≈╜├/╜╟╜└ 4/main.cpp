#include <stdio.h>


int main(void)
{
    int grade[30] = {0};
    int avr, sum = 0;
    int i;

    for(i = 0 ; i < 30 ; i++)
    {
        printf("%d�� �л� ���� �Է� : ", i+1);
        scanf("%d", &grade[i]);
        sum = sum + grade[i];
    }

    avr = sum / 30;
    for(i = 0 ; i < 30 ; i++)
    {
        printf("%d�� �л� ���� : %d\n", i+1, grade[i]);
    }

    printf("�հ� : %d\n", sum);
    printf("��� : %d\n", avr);
    return 0;

}
