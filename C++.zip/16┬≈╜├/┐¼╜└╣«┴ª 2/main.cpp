#include <stdio.h>


int main()
{
    int i, t[26] = {'a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z'};
    int a, b, c, d, e;

    scanf("%d%d%d%d%d", &a, &b, &c, &d, &e);
    printf("%d%d%d%d%d", a,b,c,d,e);
}
