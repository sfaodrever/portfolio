#include <stdio.h>


int main(void)
{
   int lol[5];
   printf("mmr�Է� : ");
   scanf("%d %d %d %d %d", &lol[0], &lol[1], &lol[2], &lol[3], &lol[4]);

   printf("ž    : %d\n", lol[0]);
   printf("�̵�  : %d\n", lol[1]);
   printf("����  : %d\n", lol[2]);
   printf("����  : %d\n", lol[3]);
   printf("����  : %d\n", lol[4]);

   return 0;
}
