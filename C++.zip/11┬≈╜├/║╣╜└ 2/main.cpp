#include <stdio.h>
int z(int q,int w)
{
  return q * w / 2;
}


int main()
{
    int a, b, c;


    printf("�غ� ���� �Է� : ");
    scanf("%d %d", &a, &b);
    c = z(a,b);

    printf("���� : %d\n", c);
    return 0;






}
