#include <stdio.h>
void z(int q,int w)
{
   if(q > w)
    printf("ū �� : %d\n", q);
   else
    printf("ū �� : %d\n", w);
}


int main()
{
    int a, b;


    printf("���� �ΰ� �Է� : ");
    scanf("%d %d", &a, &b);
    z(a, b);
    return 0;






}
