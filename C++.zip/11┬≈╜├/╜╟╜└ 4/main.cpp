#include <stdio.h>



int func(int num1 ,int num2)
{
    if(num1 > num2)
        return 1;

    else if (num1 < num2)
        return 0;

    else
        return -1;
}

int main()
{
    int a,b;
    int result;

    printf("�� �� �Է� : ");
    scanf("%d %d", &a, &b);

    result = func(a, b);

    if(result == 1)
        printf("%d > %d\n", a,b);

    else if(result == 0)
        printf("%d < %d\n", a,b);

    else
        printf("%d = %d\n", a,b);

    return 0;
}
