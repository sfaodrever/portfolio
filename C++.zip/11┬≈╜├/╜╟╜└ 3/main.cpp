#include <stdio.h>



int gugudan(int dan)
{
    int i = 1;


    printf("%d��\n", dan);
    for(i = 1; i <= 9 ; i++)
        printf("%d X %d = %d\n", dan, i, dan*i);
}

int main()
{
    int dan;


    while(1)
    {
        printf("�� �Է�(0�Է½� ����) :");
        scanf("%d", &dan);

        if(dan == 0)
        {
            printf("0�Էµ� : ����\n");
            break;
        }
        gugudan(dan);
    }
}
