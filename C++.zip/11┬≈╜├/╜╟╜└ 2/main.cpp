#include <stdio.h>
int a;


int hamsoo()
{
    int num2;
    num2 = 7777;
    printf("hamsoo �Լ� �����!\n");

    return num2;

}

int main()
{
    int num1;
    num1 = 3333;

    int num2;
    num2 = hamsoo();

    printf("num1 = %d\n", num1);
    printf("num2 = %d\n", num2);
}
