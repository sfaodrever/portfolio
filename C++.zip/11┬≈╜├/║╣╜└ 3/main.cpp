#include <stdio.h>
void gugudan(int n)
{
  int i;
  printf("==%d��==\n", n);
  for(i = 1 ; i <= 9 ; i++)
  {

      printf("%d * %d = %d\n", n, i, n*i);
  }
}


int main(void)
{
    int a;


    printf("���� �Է� : ");
    scanf("%d", &a);
    gugudan(a);


    return 0;






}
