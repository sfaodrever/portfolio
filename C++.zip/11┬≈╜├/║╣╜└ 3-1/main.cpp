#include <stdio.h>
void gugudan(int n)
{
  int i;

  for(i = 0 ; i < n ; i++)
  {

      printf("gg\n");
  }
}


int main(void)
{
    int a;


    printf("���� �Է� : ");
    scanf("%d", &a);
    gugudan(a);


    return 0;
}
